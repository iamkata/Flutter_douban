import 'dart:math';
import 'package:flutter/material.dart';
import 'package:learn_flutter/douban/model/home_model.dart';
import 'package:learn_flutter/douban/utils/log.dart';
import 'package:learn_flutter/douban/widgets/dashed_line.dart';
import 'package:learn_flutter/douban/widgets/star_rating.dart';

class HYHomeMovieItem extends StatelessWidget {
  final MovieItem movie;

  HYHomeMovieItem(this.movie);

  @override
  Widget build(BuildContext context) {
    return Container(
      // 包裹一层Container是为了好设置内边距
      padding: EdgeInsets.all(8),
      // 底部加边框，设置分隔条
      decoration: BoxDecoration(
          border:
              Border(bottom: BorderSide(width: 8, color: Color(0xffcccccc)))),
      child: Column(
        // 交叉轴左对齐
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          // 1. 头部的布局
          buildHeader(),
          SizedBox(
            height: 8,
          ),
          // 2. 内容布局
          buildContent(),
          SizedBox(
            height: 8,
          ),
          // 3. 尾部布局
          buildFooter(),
        ],
      ),
    );
  }

  // 1.头部的布局
  Widget buildHeader() {
    return Container(
      padding: EdgeInsets.fromLTRB(10, 5, 10, 5),
      decoration: BoxDecoration(
          color: Color.fromARGB(255, 238, 205, 144),
          borderRadius: BorderRadius.circular(3)),
      child: Text(
        "No.${movie.rank}",
        style: TextStyle(fontSize: 18, color: Color.fromARGB(255, 131, 95, 36)),
      ),
    );
  }

  // 2.内容的布局
  Widget buildContent() {
    return Row(
      // 交叉轴从头开始
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        buildContentImage(),
        SizedBox(
          width: 8,
        ),
        Expanded(
          // 添加IntrinsicHeight组件就能保证内容+虚线+想看高度都是一样的，这样我们就不需要设置虚线和想看的高度了
          child: IntrinsicHeight(
            child: Row(
              children: <Widget>[
                buildContentInfo(),
                SizedBox(
                  width: 8,
                ),
                // 虚线
                buildContentLine(),
                SizedBox(
                  width: 8,
                ),
                // 想看
                buildContentWish()
              ],
            ),
          ),
        )
      ],
    );
  }

  // 2.1.内容的图片
  Widget buildContentImage() {
    return ClipRRect( // 设置圆角，这种方式简单方便
        borderRadius: BorderRadius.circular(8),
        child: Image.network(
          movie.imageURL,
          // 设置高度之后宽度会自适应比例，也就是宽高固定了
          height: 150,
        ));
  }

  // 2.2.内容的信息
  Widget buildContentInfo() {
    // 因为左边的图片和让Column都是在一个row里面，如果文字过多，文字会超出屏幕外面
    // 所以我们让Column变成可伸缩的，从而不超出屏幕
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          buildContentInfoTitle(),
          SizedBox(
            height: 8,
          ),
          buildContentInfoRate(),
          SizedBox(
            height: 8,
          ),
          buildContentInfoDesc()
        ],
      ),
    );
  }

//  2.2.1 内容的信息的标题
  Widget buildContentInfoTitle() {
    List<InlineSpan> spans = [];

    // 图标+电影名称+年份，使用row也是可以实现的，但是以后文字多的时候row无法换行，所以使用如下方式
    return Text.rich(
      TextSpan(children: [
        // 以前我们用的是WidgetSpan+textSpan+textSpan,但是这样会导致前两个不在一条水平线上
        // 现在我们三个都使用WidgetSpan，然后前两个设置PlaceholderAlignment.middle，最后一个设置PlaceholderAlignment.bottom
        // 就可以让前两个中心点对齐，最后一个底部对齐
        // 图标
        WidgetSpan(
          child: Icon(
            Icons.play_circle_outline,
            color: Colors.pink,
            size: 40,
          ),
          baseline: TextBaseline.ideographic,
          alignment: PlaceholderAlignment.middle
        ),
        // 电影名称
        // WidgetSpan要么都是一行显示，要么就三行显示，如果电影的名字过长，就无法做到两行显示的效果
        // 我们的解决办法是让每个文字都是一个WidgetSpan，runes就是每个文字组成的数组，使用map映射成WidgetSpan的 Iterable，再转成数组，再展开
        ...movie.title.runes.map((rune) {
          return WidgetSpan(child: Text(new String.fromCharCode(rune), style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),), alignment: PlaceholderAlignment.middle);
        }).toList(),
        // 年份
        WidgetSpan(child: Text("(${movie.playDate})"), style: TextStyle(fontSize: 18, color: Colors.grey), alignment: PlaceholderAlignment.bottom)
      ])
    );
  }

  // 2.2.2 星级评分组件
  Widget buildContentInfoRate() {
    // 当在iPhone5小尺寸手机上的时候，左边图片的宽度是固定的，右边的虚线和想看的宽度也是固定的
    // 这时候剩下的宽度也许都不够星星的宽度了，这时候就会报错
    // 我们添加FittedBox，这时候如果剩下的宽度不够了，就可以稍微缩小一点，这样就不会报错了
    return FittedBox(
      child: Row(
        children: <Widget>[
          // 以前封装的星级=插件☆
          HYStarRating(
            rating: movie.rating,
            size: 20,
          ),
          SizedBox(
            width: 6,
          ),
          // 星级文字  
          Text(
            "${movie.rating}",
            style: TextStyle(fontSize: 16),
          )
        ],
      ),
    );
  }

  // 2.2.3 电影描述
  Widget buildContentInfoDesc() {
    // 1.字符串拼接
    // 数组元素以空格拼接
    final genresString = movie.genres.join(" ");
    // 导演
    final directorString = movie.director.name;
    List<Actor> casts = movie.casts;
    // 演员数组取出名字
    final actorString = movie.casts.map((item) => item.name).join(" ");

    return Text(
      "$genresString / $directorString / $actorString",
      maxLines: 2, //最多两行
      overflow: TextOverflow.ellipsis, //超出以后显示...
      style: TextStyle(fontSize: 16),
    );
  }

  // 2.3.内容的虚线
  Widget buildContentLine() {
    return Container(
//      height: 100,
      child: HYDashedLine(
        axis: Axis.vertical,
        dashedWidth: .4,
        dashedHeight: 6,
        count: 10,
        color: Colors.pink,
      ),
    );
  }

  // 2.4.内容的想看
  Widget buildContentWish() {
    return Container(
//      height: 100,
      child: Column(
        // 包裹一个Container，再设置为center，让❤和想看垂直居中
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Image.asset("assets/images/home/wish.png"),
          Text(
            "想看",
            style: TextStyle(
              fontSize: 18,
              color: Color.fromARGB(255, 235, 170, 60)
            ),
          )
        ],
      ),
    );
  }

  // 3.尾部的布局
  Widget buildFooter() {
    return Container(
      // 默认的宽度是内容包裹的宽度，设置为最大
      width: double.infinity,
      // 内边距
      padding: EdgeInsets.all(8),
      // 圆角
      decoration: BoxDecoration(
        color: Color(0xfff2f2f2),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        movie.originalTitle,
        style: TextStyle(fontSize: 20, color: Color(0xff666666)),
      ),
    );
  }
}
