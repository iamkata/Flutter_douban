import 'package:flutter/material.dart';
import 'initialize_items.dart';

class HYMainPage extends StatefulWidget {
  @override
  _HYMainPageState createState() => _HYMainPageState();
}

class _HYMainPageState extends State<HYMainPage> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // 以前我们演示代码的时候，MaterialApp里面有个home属性，我们把home属性设置为HYHomePage
      // 然后在HYHomePage里面添加Scaffold，appBar中的appBar就是导航条，body就是我们演示的页面

      // 现在body我们要设置为IndexedStack，这个组件的index属性是多少，就会将对应index的page放到最上面
      // 这就实现了点击底部tabbar切换page的效果了
      body: IndexedStack(
        // 当前显示哪个界面
        index: _currentIndex,
        // 页面数组
        children: pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        // 设置文字大小
        selectedFontSize: 14,
        unselectedFontSize: 14,
        selectedItemColor: Colors.red,
        // 默认选中哪个item
        currentIndex: _currentIndex,
        // 当下面的item超过2个的时候，要设置这个属性为fixed，否则文字将会不显示
        type: BottomNavigationBarType.fixed,
        // items数组
        items: items,
        // 点击事件
        onTap: (index) {
          setState(() {
            _currentIndex = index;
          });
        },
      ),
    );
  }
}

