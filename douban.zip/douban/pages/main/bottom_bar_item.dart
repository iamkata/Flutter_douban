import 'package:flutter/material.dart';

//将这些代码抽到一个方法中是可以的，当然也可以抽到类中，然后将参数传递给父类即可
//使用了初始化列表
class HYBottomBarItem extends BottomNavigationBarItem {
  HYBottomBarItem(String iconName, String title)
      : super(
    title: Text(title),
    // 默认是false，点击的时候会先删除旧图，再加载新图，中间会有空白的闪烁
    // 设置gaplessPlayback: true之后，当点击按钮后，新图加载完之后才会把旧图删点，不会闪烁
    icon: Image.asset("assets/images/tabbar/$iconName.png", width: 32, gaplessPlayback: true,),
    activeIcon: Image.asset("assets/images/tabbar/${iconName}_active.png", width: 32, gaplessPlayback: true,),
  );
}