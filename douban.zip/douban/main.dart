import 'package:flutter/material.dart';
import 'pages/main/main.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.green,
        splashColor: Colors.transparent,
        // 默认点击的时候会有水波纹的效果，设置为透明，去掉这个效果
        highlightColor: Colors.transparent
      ),
      home: HYMainPage(),
    );
  }
}







