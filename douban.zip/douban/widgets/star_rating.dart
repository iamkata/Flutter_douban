
import 'package:flutter/material.dart';

class HYStarRating extends StatefulWidget {
  final double rating; //当前分数
  final double maxRating; // 最大分数
  final int count; // 星星个数
  final double size; // 星星大小
  final Color unselectedColor; // 未选中的颜色
  final Color selectedColor; // 选中的颜色
  final Widget unselectedImage; //未选中的图片
  final Widget selectedImage; //选中的图片

  // 初始化方法
  HYStarRating({
    @required this.rating,
    this.maxRating = 10,
    this.count = 5,
    this.size = 30,
    this.unselectedColor = const Color(0xffbbbbbb), // 默认值必须是个常量，所以加个const
    this.selectedColor = const Color(0xffff0000),
    Widget unselectedImage,
    Widget selectedImage
    // 初始化列表
  }): unselectedImage = unselectedImage ?? Icon(Icons.star_border, color: unselectedColor, size: size),
        selectedImage = selectedImage ?? Icon(Icons.star, color: selectedColor, size: size);

  @override
  _HYStarRatingState createState() => _HYStarRatingState();
}

class _HYStarRatingState extends State<HYStarRating> {
  @override
  Widget build(BuildContext context) {
    return Stack(
      children: <Widget>[
        Row(mainAxisSize: MainAxisSize.min, children: buildUnselectedStar()),
        Row(mainAxisSize: MainAxisSize.min, children: buildSelectedStar())
      ],
    );
  }

  // 创建未选中的star
  List<Widget> buildUnselectedStar() {
    // 如果在state里面想拿到widget里面的数据，直接使用widget即可
    return List.generate(widget.count, (index) {
      return widget.unselectedImage;
    });
  }

  // 创建选中的star
  List<Widget> buildSelectedStar() {
    // 1.创建stars
    List<Widget> stars = [];
    final star = widget.selectedImage;

    // 2.构建满填充的star
    // 一个星代表几分
    double oneValue = widget.maxRating / widget.count;
    // floor向下取整，获取有几个整的星
    // floor是地板的意思，向下取整，ceil是天花板的意思，向上取整
    int entireCount = (widget.rating / oneValue).floor();
    for (var i = 0; i < entireCount; i++) {
      stars.add(star);
    }

    // 3.构建部分填充star
    // (widget.rating / oneValue) 3.5 - 3 = 0.5 * widget.size
    // 计算需要裁剪的宽度
    double leftWidth = ((widget.rating / oneValue) - entireCount) * widget.size;
    final halfStar = ClipRect(
        clipper: HYStarClipper(leftWidth),
        child: star
    );
    stars.add(halfStar);

    // 边界处理
    if (stars.length > widget.count) {
      return stars.sublist(0, widget.count);
    }

    return stars;
  }
}

// 系统提供的抽象类的子类我们用不了，自己实现一个
class HYStarClipper extends CustomClipper<Rect> {
  double width;

  HYStarClipper(this.width);

  @override
  Rect getClip(Size size) {
    // 返回裁剪的范围
    return Rect.fromLTRB(0, 0, width, size.height);
  }

  @override
  bool shouldReclip(HYStarClipper oldClipper) {
    // 宽度变化之后才裁剪
    return oldClipper.width != this.width;
  }
}
