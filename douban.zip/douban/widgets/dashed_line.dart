import 'package:flutter/material.dart';

class HYDashedLine extends StatelessWidget {
  final Axis axis; //虚线的方向
  final double dashedWidth; // 虚线宽度
  final double dashedHeight;// 虚线高度
  final int count; // 虚线个数
  final Color color;

  HYDashedLine({
    // 设置默认值
    this.axis = Axis.horizontal,
    this.dashedWidth = 1,
    this.dashedHeight = 1,
    this.count = 10,
    this.color = Colors.red
  });

  @override
  Widget build(BuildContext context) {
    return Flex(
      direction: axis,
      // 设置虚线的排布方式
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(count, (_) {
        // 每一个SizedBox就是一个虚线
        return SizedBox(
          width: dashedWidth,
          height: dashedHeight,
          // 给SizedBox设置背景色
          child: DecoratedBox(
            decoration: BoxDecoration(color: color),
          ),
        );
      }),
    );
  }
}